sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("mrpl.etender.ceg.controller.cegform", {
        onInit: function () {

        }
    });
});
