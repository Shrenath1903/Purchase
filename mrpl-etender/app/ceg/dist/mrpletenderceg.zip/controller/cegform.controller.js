sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("mrpl.etender.ceg.controller.cegform",{onInit:function(){}})});
//# sourceMappingURL=cegform.controller.js.map