sap.ui.define([
	"mrplmmreleasedprs/purchasereq/test/unit/controller/Overview.controller"
], function () {
	"use strict";
});
