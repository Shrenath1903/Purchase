sap.ui.define([
	"mrpletender/austerityapproval/test/unit/controller/austerityapproval.controller"
], function () {
	"use strict";
});
