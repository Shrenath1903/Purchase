/* global QUnit */

sap.ui.require(["mrpl/etender/austerityapproval/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
