sap.ui.define([
	"mrpletender/singlecertificatetender/test/unit/controller/sctForm.controller"
], function () {
	"use strict";
});
