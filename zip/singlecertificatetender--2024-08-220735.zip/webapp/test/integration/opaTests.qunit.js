/* global QUnit */

sap.ui.require(["mrpl/etender/singlecertificatetender/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
