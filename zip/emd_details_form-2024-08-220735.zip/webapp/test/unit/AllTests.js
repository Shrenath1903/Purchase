sap.ui.define([
	"emd_details_form/test/unit/controller/Emd_form.controller"
], function () {
	"use strict";
});
