/* global QUnit */

sap.ui.require(["emddetailsform/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
