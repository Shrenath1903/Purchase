sap.ui.define([
	"mrpletender/pqc/test/unit/controller/pqcForm.controller"
], function () {
	"use strict";
});
