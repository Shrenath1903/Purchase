/* global QUnit */

sap.ui.require(["mrpl/mm/releasedprs/purchasereq/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
