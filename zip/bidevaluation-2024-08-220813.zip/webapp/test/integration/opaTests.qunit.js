/* global QUnit */

sap.ui.require(["mrpl/etender/bidevaluation/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
