sap.ui.define([
	"mrpletender/bidevaluation/test/unit/controller/bidEvaluationform.controller"
], function () {
	"use strict";
});
