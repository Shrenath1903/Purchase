/* global QUnit */

sap.ui.require(["mrpl/etender/ceg/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
