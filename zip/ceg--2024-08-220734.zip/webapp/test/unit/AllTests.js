sap.ui.define([
	"mrpletender/ceg/test/unit/controller/cegform.controller"
], function () {
	"use strict";
});
