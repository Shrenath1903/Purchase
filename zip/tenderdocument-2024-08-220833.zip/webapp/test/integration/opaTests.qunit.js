/* global QUnit */

sap.ui.require(["mrpl/etender/tenderdocument/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
