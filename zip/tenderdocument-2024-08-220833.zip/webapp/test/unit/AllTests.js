sap.ui.define([
	"mrpletender/tenderdocument/test/unit/controller/TenderDocument.controller"
], function () {
	"use strict";
});
