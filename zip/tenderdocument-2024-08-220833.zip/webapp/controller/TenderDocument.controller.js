sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("mrpl.etender.tenderdocument.controller.TenderDocument", {
        onInit: function () {

        }
    });
});
