sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("mrpl.etender.emd.controller.Emd_form", {
        onInit: function () {

        }
    });
});
